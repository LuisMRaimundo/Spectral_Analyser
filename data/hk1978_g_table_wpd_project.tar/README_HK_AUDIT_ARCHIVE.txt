HK g(y) visual redigitisation audit archive

Contents:
- _hk_new_table.csv: y,g redigitised values.
- _hk_digitisation_metadata.txt: prose provenance and methodological note.
- _hk_calibration_and_extraction.json: calibration and extraction parameters.
- hutchinson1978_fig1_plot_area_300dpi.png: plot-area image used for extraction.
- hutchinson1978_fig1_crop_300dpi.png: wider figure crop retained for audit context.

Important limitation:
This archive is named _hk_wpd_project.tar because the downstream Cursor workflow expects that filename. However, it was generated as an audit TAR archive from the supplied PDF crop, not saved from the WebPlotDigitizer browser interface. If a strict native WebPlotDigitizer project is required, open the included figure image in WebPlotDigitizer, load/import the CSV points, and save a native WPD project manually.
